<?php 
/**
 * Plugin Name: Custom API
 */

function wl_posts() {
    // READ THE JSON FILE
    $raw_data = file_get_contents("http://localhost/wp-content/uploads/2022/11/data.json");
    // DECODE THE JSON FILE
    $data = json_decode($raw_data,true);
    return $data;
}

 add_action('rest_api_init', function() {

    register_rest_route('wl/v1', 'posts', [
        'methods' => 'GET',
        'callback' => 'wl_posts',

    ]);
 });
?>

